/* $Id: vbrender.h,v 1.2 1999/09/18 20:41:23 keithw Exp $ */

/*
 * Mesa 3-D graphics library
 * Version:  3.1
 * 
 * Copyright (C) 1999  Brian Paul   All Rights Reserved.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * BRIAN PAUL BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
 * AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */





#ifndef VBRENDER_H
#define VBRENDER_H


#include "types.h"


extern void gl_set_render_vb_function( GLcontext *ctx );

extern void gl_render_vb( struct vertex_buffer *VB );

extern void gl_init_vbrender( void );


/* Needed by vbindirect.c:
 */
extern void gl_render_clipped_triangle( GLcontext *ctx, GLuint n, 
					GLuint vlist[], 
					GLuint pv );

extern void gl_render_clipped_line( GLcontext *ctx, GLuint v1, GLuint v2 );

extern void gl_reduced_prim_change( GLcontext *ctx, GLenum prim );

#endif
