#define MESA_MAJOR_VERSION		3
#define MESA_MINOR_VERSION		1
#define MESA_RELEASE_STAGE		0x60	/* beta */
#define MESA_RELEASE_VERSION	7
#define MESA_SHORT_VERSION_STRING	"3.1b7"
#define MESA_LONG_VERSION_STRING	"3.1b7, � Brian Paul 1995-1999, � Miklos Fazekas 1995-1999"
#define MESA_SECOND_VERSION_STRING	"Mesa3DfxEngine 3.1b7"

#include "Mesa3DGraphicsLibrary.r"
